Taskly is your everyday task app which helps you to manage your tasks efficiently

